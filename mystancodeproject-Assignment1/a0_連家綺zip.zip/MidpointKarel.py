"""
File: MidpointKarel.py
Name: Jessie
----------------------------
When finished, this program should leave a beeper
on the corner closest to the midpoint of 1st Street.

If 1st Street has an even number of corners,
either of the two central corners is acceptable.
Karel may use additional beepers while searching
for the midpoint, but must remove them before stopping.

The world can be of any size, and you may assume
that it is at least as tall as it is wide.
"""

from karel.stanfordkarel import *

def main():
    """
    Pre-condition: Karel is facing east,at (1,1)
    Post-condition: Karel is facing east on beeper, at (1,3)
    """
    put_beeper()
    while front_is_clear():
        move()
        put_beeper()
    turn_around()
    while front_is_clear():
        move()

def turn_around():
    turn_left()
    turn_left()

    """
    還未完成作業
    “”“

    # move()
    # move()
    # put_beeper()
    # pick_beeper()
    # while on_beeper():
    #     while on_beeper():
    #         move()
    #     put_beeper()
    #     turn_around()
    #     while front_is_clear():
    #         move()
    #     turn_around()
    #     pick_beeper()


# DO NOT EDIT CODE BELOW THIS LINE #


if __name__ == '__main__':
    execute_karel_task(main)
